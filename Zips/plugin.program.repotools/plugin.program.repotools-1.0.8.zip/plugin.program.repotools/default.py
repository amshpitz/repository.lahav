#!/usr/bin/env python
# -*- coding: utf-8 -*-
# thanks to tomer haimovitch for the help in this add-on

import os,sys,urllib
import xbmcaddon,xbmcplugin,xbmcgui
import orphAddon
import videoAddon
import MusicAddon
import DocuAddon
import addonsettings
import HeAddon
import shutil

Config = xbmcaddon.Addon()
dialog = xbmcgui.Dialog()
Progress = xbmcgui.DialogProgress()
showed = xbmc.translatePath(os.path.join('special://home/addons/plugin.program.repotools', 'showed'))



if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.repotools')):
    shutil.rmtree(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.repotools'))
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")
else: pass



if os.path.isfile(showed) ==  'true':
    f = open(showed,"w+")
    f.write("")
    f.close()
    
else: Config.openSettings()

if Config.getSetting("ToMeRepo") == 'true' or Config.getSetting("TheWiz") == 'true' or Config.getSetting("nirepo") == 'true' or Config.getSetting("kodisrael") == 'true' or Config.getSetting("featherence") == 'true' or Config.getSetting("abeksis") == 'true' or Config.getSetting("xbmcisrael") == 'true' or Config.getSetting("thevibe") == 'true' or Config.getSetting("superrepo") == 'true' or Config.getSetting("xunitytalk") == 'true' or Config.getSetting("xbmchub") == 'true':
    
    Progress.create("מתקין מאגרי רפו...", "נא להמתין...")
    Progress.update(0)

    if Config.getSetting("ToMeRepo") == 'true':
        orphAddon.ToMeRepo()
        Progress.update(10)
    else: pass

    if Config.getSetting("TheWiz") == 'true':
        orphAddon.TheWiz()
        Progress.update(20)
    else: pass

    if Config.getSetting("kodisrael") == 'true':
        orphAddon.kodisrael()
        Progress.update(40)
    else: pass

    if Config.getSetting("featherence") == 'true':
        orphAddon.featherence()
        Progress.update(40)
    else: pass

    if Config.getSetting("abeksis") == 'true':        
        orphAddon.abeksis()
        Progress.update(55)
    else: pass

    if Config.getSetting("xbmcisrael") == 'true':
        orphAddon.xbmcisrael()
        Progress.update(65)
    else: pass

    if Config.getSetting("thevibe") == 'true':
        orphAddon.thevibe()
        Progress.update(75)
    else: pass

    if Config.getSetting("nirepo") == 'true':
        orphAddon.nirepo()
        Progress.update(80)
    else: pass	
	
    if Config.getSetting("superrepo") == 'true':
        orphAddon.superrepo()
        Progress.update(85)
    else: pass
   
    if Config.getSetting("xunitytalk") == 'true':
        orphAddon.xunitytalk()
        Progress.update(90)
    else: pass
	
    if Config.getSetting("xbmchub") == 'true':
        orphAddon.xbmchub()
        Progress.update(95)
    else: pass
	
    Progress.update(100)
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")   


if Config.getSetting("Exodus_Settings") == 'true' or Config.getSetting("Salts_Settings") == 'true' or Config.getSetting("Meta_Settings") == 'true' or Config.getSetting("Specto_Settings") == 'true' or Config.getSetting("Pvr_Settings") == 'true':
    
    Progress.create("מתקין הגדרות להרחבות...", "נא להמתין...")
    Progress.update(0)

    if Config.getSetting("Exodus_Settings") == 'true' :
        addonsettings.Exodus_Settings() 	
        Progress.update(10)
    else: pass	

    if Config.getSetting("Salts_Settings") == 'true' :
        addonsettings.Salts_Settings()    	
        Progress.update(20)
    else: pass	

    if Config.getSetting("Meta_Settings") == 'true' :
        addonsettings.Meta_Settings()       	
        Progress.update(40)
    else: pass

    if Config.getSetting("Specto_Settings") == 'true' :
        addonsettings.Specto_Settings()       	
        Progress.update(70)
    else: pass

    if Config.getSetting("Pvr_Settings") == 'true' :
        addonsettings.Pvr_Settings()       	
        Progress.update(80)
    else: pass
	
    Progress.update(100)
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")   	
	
if Config.getSetting("Decado") == 'true' or Config.getSetting("Brettus") == 'true' or Config.getSetting("Featherencedocu") == 'true' or Config.getSetting("Documentarytube") == 'true' or Config.getSetting("iconspire") == 'true':
    
    Progress.create("מתקין הרחבות דוקומנטריה...", "נא להמתין...")
    Progress.update(0)

    if Config.getSetting("Decado") == 'true' :
        DocuAddon.Decado()
        videoAddon.t0mm0()
        videoAddon.youtube()
        videoAddon.commonplugincache()		
        Progress.update(20)
    else: pass
	
    if Config.getSetting("Featherencedocu") == 'true' :
        DocuAddon.Featherencedocu()
        videoAddon.featherenceservice()
        Progress.update(40)
    else: pass	

    if Config.getSetting("Documentarytube") == 'true' :
        DocuAddon.Documentarytube()
        videoAddon.youtube()		
        Progress.update(60)		
    else: pass

    if Config.getSetting("Brettus") == 'true' :
        DocuAddon.Brettus()
        videoAddon.youtube()		
        Progress.update(70)		
    else: pass
	
    if Config.getSetting("iconspire") == 'true' :
        DocuAddon.iconspire()
        videoAddon.youtube()		
        Progress.update(90)
    else: pass	

    Progress.update(100)
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")
    
if Config.getSetting("opensubtitles") == 'true' or Config.getSetting("ktuvit") == 'true' or Config.getSetting("subcenter") == 'true':
    
    Progress.create("מתקין הרחבות כתוביות...", "נא להמתין...")
    Progress.update(0)

    if Config.getSetting("subcenter") == 'true' :
        DocuAddon.subcenter()
        videoAddon.commonplugincache()
        Progress.update(40)
    else: pass	

    if Config.getSetting("ktuvit") == 'true' :
        DocuAddon.ktuvit()
        videoAddon.commonplugincache()		
        Progress.update(60)		
    else: pass

    if Config.getSetting("opensubtitles") == 'true' :
        DocuAddon.opensubtitles()		
        Progress.update(90)
    else: pass	

    Progress.update(100)
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")


if Config.getSetting("KMusicTube") == 'true' or Config.getSetting("TheMusicSource") == 'true' or Config.getSetting("ninfm") == 'true' or Config.getSetting("mimfm") == 'true' or Config.getSetting("Jango") == 'true' or Config.getSetting("livehd") == 'true' or Config.getSetting("FeatherenceMusic") == 'true':
    
    Progress.create("מתקין הרחבות מוזיקה...", "נא להמתין...")
    Progress.update(0)

    if Config.getSetting("KMusicTube") == 'true' :
        MusicAddon.KMusicTube()
        videoAddon.t0mm0()
        videoAddon.youtube()
        videoAddon.requests()		
        Progress.update(10)
    else: pass
	
    if Config.getSetting("TheMusicSource") == 'true' :
        MusicAddon.TheMusicSource()
        videoAddon.beautifulsoup()
        videoAddon.beautifulsoup4()
        videoAddon.simpledownloader()		
        videoAddon.requests()
        videoAddon.youtube()
        videoAddon.parsedom()		
        videoAddon.commonplugincache()
        videoAddon.httplib2()
        videoAddon.youtubedl()
        videoAddon.urlresolver()
        videoAddon.simplejson()		
        Progress.update(30)
    else: pass	

    if Config.getSetting("FeatherenceMusic") == 'true' :
        MusicAddon.FeatherenceMusic()
        videoAddon.featherenceservice()		
        Progress.update(40)		
    else: pass

    if Config.getSetting("Jango") == 'true' :
        MusicAddon.Jango()
        videoAddon.t0mm0()
        videoAddon.requests()		
        Progress.update(50)
    else: pass	

    if Config.getSetting("livehd") == 'true' :
        MusicAddon.livehd()
        videoAddon.youtube()
        videoAddon.frenchdj()		
        Progress.update(80)
    else: pass	

    if Config.getSetting("ninfm") == 'true' :
        MusicAddon.ninfm()
        orphAddon.nirepo()
        videoAddon.beautifulsoup4()	
        videoAddon.requests()		
        videoAddon.xbmcswift()
        videoAddon.html5lib()		
        Progress.update(90)
    else: pass
	
    if Config.getSetting("mimfm") == 'true' :
        MusicAddon.mimfm()
        orphAddon.nirepo()
        videoAddon.beautifulsoup4()        	
        videoAddon.requests()		
        videoAddon.xbmcswift()
        videoAddon.html5lib()		
        Progress.update(95)
    else: pass	
	
    Progress.update(100)
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")
    

if Config.getSetting("KidsIl") == 'true' or Config.getSetting("hotvod") == 'true' or Config.getSetting("moviesil") == 'true' or Config.getSetting("nostalgia") == 'true' or Config.getSetting("channelone") == 'true' or Config.getSetting("channelten") == 'true' or Config.getSetting("reshet") == 'true' or Config.getSetting("walla") == 'true' or Config.getSetting("makoTV") == 'true' or Config.getSetting("hetrailers") == 'true' or Config.getSetting("AnarchiTV") == 'true' or Config.getSetting("Vodil") == 'true'  :
    
    Progress.create("מתקין הרחבות ישראליות", "נא להמתין...")
    Progress.update(0)

    if Config.getSetting("nostalgia") == 'true' :
        HeAddon.nostalgia()
        videoAddon.youtube()       		
        Progress.update(10)
    else: pass
	
    if Config.getSetting("moviesil") == 'true' :
        HeAddon.moviesil()
        videoAddon.youtube()
        Progress.update(15)
    else: pass
	
    if Config.getSetting("hotvod") == 'true' :
        HeAddon.hotvod()       	
        Progress.update(20)
    else: pass

    if Config.getSetting("AnarchiTV") == 'true' :
        HeAddon.AnarchiTV()
        videoAddon.beautifulsoup4()		
        videoAddon.requests()		
        videoAddon.html5lib()		
        Progress.update(25)
    else: pass

    if Config.getSetting("KidsIl") == 'true' :
        HeAddon.KidsIl()
        videoAddon.youtube()
        videoAddon.xbmcisrael()        	
        Progress.update(28)
    else: pass
	
    if Config.getSetting("Vodil") == 'true' :
        HeAddon.Vodil()
        videoAddon.youtube()		 
        Progress.update(30)
    else: pass
		
    if Config.getSetting("hetrailers") == 'true' :
        HeAddon.hetrailers()
        Progress.update(45)
    else: pass
	
    if Config.getSetting("makoTV") == 'true' :
        HeAddon.makoTV()
        videoAddon.xbmcisrael()		
        Progress.update(50)
    else: pass	

    if Config.getSetting("walla") == 'true' :
        HeAddon.walla()
        videoAddon.xbmcisrael()	
        videoAddon.commonplugincache()		
        Progress.update(60)
    else: pass	
	
    if Config.getSetting("reshet") == 'true' :
        HeAddon.reshet()
        videoAddon.xbmcisrael()	
        Progress.update(70)
    else: pass		
	
    if Config.getSetting("channelten") == 'true' :
        HeAddon.channelten()
        videoAddon.xbmcisrael()	
        Progress.update(80)
    else: pass

    if Config.getSetting("channelone") == 'true' :
        HeAddon.channelone()
        videoAddon.xbmcisrael()	
        Progress.update(90)
    else: pass


    Progress.update(100)
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")


if Config.getSetting("Exodus") == 'true' or Config.getSetting("AlphaMovies") == 'true' or Config.getSetting("salts") == 'true' or Config.getSetting("DandyMedia") == 'true' or Config.getSetting("Evolve") == 'true' or Config.getSetting("channelone") == 'true' or Config.getSetting("channelten") == 'true' or Config.getSetting("reshet") == 'true' or Config.getSetting("walla") == 'true' or Config.getSetting("makoTV") == 'true' or Config.getSetting("hetrailers") == 'true' or Config.getSetting("Phoenix") == 'true' or Config.getSetting("AnarchiTV") == 'true' or Config.getSetting("specto") == 'true' or Config.getSetting("Vodil") == 'true' or Config.getSetting("meta") == 'true' or Config.getSetting("ccloudtv") == 'true':
    
    Progress.create("מתקין הרחבות וידאו...", "נא להמתין...")
    Progress.update(0)

    if Config.getSetting("Exodus") == 'true' :
        videoAddon.Exodus()
        videoAddon.youtube()
        videoAddon.metahandler()
        videoAddon.urlresolver()
        videoAddon.Exodusrepo()		
        Progress.update(10)
    else: pass
	
    if Config.getSetting("salts") == 'true' :
        videoAddon.salts()
        videoAddon.urlresolver()
        videoAddon.myconnpy()
        Progress.update(30)
    else: pass
	
    if Config.getSetting("Phoenix") == 'true' :
        videoAddon.Phoenix()
        videoAddon.youtube()
        videoAddon.pyxbmct()
        videoAddon.liveresolver()
        videoAddon.urlresolver()		
        Progress.update(40)
    else: pass

    if Config.getSetting("specto") == 'true' :
        videoAddon.specto()
        videoAddon.spectomedia()
        videoAddon.filmkodi()		
        videoAddon.youtube()
        videoAddon.metahandler()
        videoAddon.requests()		
        Progress.update(50)
    else: pass
	
    if Config.getSetting("meta") == 'true' :
        videoAddon.meta()
        videoAddon.futures()
        videoAddon.requests()
        Progress.update(60)
    else: pass
	
    if Config.getSetting("Evolve") == 'true' :
        videoAddon.Evolve()
        videoAddon.liveresolver()
        videoAddon.urlresolver()		
        videoAddon.simplejson()
        videoAddon.f4mTester()		
        videoAddon.commonplugincache()
        videoAddon.youtube()		
        Progress.update(70)
    else: pass	

    if Config.getSetting("ccloudtv") == 'true' :
        videoAddon.ccloudtv()
        Progress.update(80)
    else: pass

    if Config.getSetting("DandyMedia") == 'true' :
        videoAddon.DandyMedia()
        videoAddon.t0mm0()
        videoAddon.beautifulsoup()
        videoAddon.beautifulsoup4()	
        videoAddon.simpledownloader()
        videoAddon.requests()
        videoAddon.httplib2()
        videoAddon.youtubedl()		
        videoAddon.urlresolver()
        videoAddon.metahandler()		
        videoAddon.simplejson()
        videoAddon.commonplugincache()
        videoAddon.youtube()
        orphAddon.xunitytalk()		
        Progress.update(90)
    else: pass		

    if Config.getSetting("AlphaMovies") == 'true' :
        videoAddon.AlphaMovies()
        videoAddon.t0mm0()
        videoAddon.beautifulsoup()
        videoAddon.beautifulsoup4()	
        videoAddon.simpledownloader()
        videoAddon.requests()
        videoAddon.httplib2()
        videoAddon.youtubedl()		
        videoAddon.urlresolver()
        videoAddon.metahandler()		
        videoAddon.simplejson()
        videoAddon.commonplugincache()
        videoAddon.youtube()
        orphAddon.merlin()		
        Progress.update(95)
    else: pass		
	
    Progress.update(100)
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")
    dialog.ok('senyor tools', 'ההרחבות הנבחרות הותקנו בהצלחה')


else: pass


Config.setSetting(id='ToMeRepo', value='false')
Config.setSetting(id='TheWiz', value='false')
Config.setSetting(id='kodisrael', value='false')
Config.setSetting(id='featherence', value='false')
Config.setSetting(id='abeksis', value='false')
Config.setSetting(id='xbmcisrael', value='false')
Config.setSetting(id='thevibe', value='false')
Config.setSetting(id='superrepo', value='false')
Config.setSetting(id='xunitytalk', value='false')
Config.setSetting(id='xbmchub', value='false')
Config.setSetting(id='nirepo', value='false')

Config.setSetting(id='Exodus', value='false')
Config.setSetting(id='salts', value='false')
Config.setSetting(id='Phoenix', value='false')
Config.setSetting(id='AnarchiTV', value='false')
Config.setSetting(id='specto', value='false')
Config.setSetting(id='Vodil', value='false')
Config.setSetting(id='meta', value='false')
Config.setSetting(id='ccloudtv', value='false')
Config.setSetting(id='hetrailers', value='false')
Config.setSetting(id='makoTV', value='false')
Config.setSetting(id='walla', value='false')
Config.setSetting(id='reshet', value='false')
Config.setSetting(id='channelten', value='false')
Config.setSetting(id='channelone', value='false')
Config.setSetting(id='Evolve', value='false')
Config.setSetting(id='DandyMedia', value='false')
Config.setSetting(id='nostalgia', value='false')
Config.setSetting(id='moviesil', value='false')
Config.setSetting(id='hotvod', value='false')
Config.setSetting(id='KidsIl', value='false')
Config.setSetting(id='AlphaMovies', value='false')

Config.setSetting(id='KMusicTube', value='false')
Config.setSetting(id='TheMusicSource', value='false')
Config.setSetting(id='FeatherenceMusic', value='false')
Config.setSetting(id='Jango', value='false')
Config.setSetting(id='livehd', value='false')
Config.setSetting(id='ninfm', value='false')
Config.setSetting(id='mimfm', value='false')

Config.setSetting(id='Decado', value='false')
Config.setSetting(id='Featherencedocu', value='false')
Config.setSetting(id='Documentarytube', value='false')
Config.setSetting(id='iconspire', value='false')
Config.setSetting(id='Brettus', value='false')

Config.setSetting(id='subcenter', value='false')
Config.setSetting(id='ktuvit', value='false')
Config.setSetting(id='opensubtitles', value='false')

Config.setSetting(id='Exodus_Settings', value='false')
Config.setSetting(id='Salts_Settings', value='false')
Config.setSetting(id='Meta_Settings', value='false')
Config.setSetting(id='Specto_Settings', value='false')
Config.setSetting(id='Pvr_Settings', value='false')


sys.exit()

