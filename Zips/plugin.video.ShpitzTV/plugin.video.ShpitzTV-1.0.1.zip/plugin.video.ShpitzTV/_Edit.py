import xbmcaddon

MainBase = 'https://raw.githubusercontent.com/amshpitz/repository.lahav/master/LiveTV/Home.txt'
addon = xbmcaddon.Addon('plugin.video.ShpitzTV')