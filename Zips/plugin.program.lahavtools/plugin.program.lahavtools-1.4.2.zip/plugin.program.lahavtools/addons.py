# -*- coding: utf-8 -*-

import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import plugintools
import CheckPath
import zipfile
import ntpath

MetaSettingsUrl = 'http://www.the-vibe.co.il/Wizard/wtf/?category=addonsettings&Id=102'
QuasarSettingsUrl = 'http://www.the-vibe.co.il/Wizard/wtf/?category=addonsettings&Id=33'
SaltsSettingsUrl = 'http://www.the-vibe.co.il/Wizard/wtf/?category=addonsettings&Id=34'

metasettingsPath = xbmc.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.meta','players'))
quasarsettingsPath = xbmc.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.quasar','settings.xml'))
saltssettingsPath = xbmc.translatePath(os.path.join('special://home','userdata','addon_data','plugin.video.salts','settings.xml'))

def downloadMetaSettings(url, dest, dp=None):
    if not dp:
        dp = xbmcgui.DialogProgress()
        dp.create("התקנת הגדרות","מוריד קובץ הגדרות, אנא המתן!",' ', ' ')
    dp.update(0)
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
	
def GetMetaSettings(name,url):
        path = xbmc.translatePath(os.path.join('special://home','addons','packages'))
        dp = xbmcgui.DialogProgress() 
        dp.create("Eminence zeev - הפעלה ראשונה","מתקין הגדרת נגנים עבור הרחבת חיפוש META ",'','רץ בפתיחה ראשונה בלבד') 
        lib = os.path.join(path,name + '.zip')
        try: os.remove(lib)
        except: pass
        downloadMetaSettings(url,lib,dp)
        time.sleep(2)
        #dp.update(0,"","Installing selections.....")
        all(lib,xbmc.translatePath('special://home'),'')
        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.executebuiltin("UpdateAddonRepos")

def GetQuasarSettings(name,url):
        path = xbmc.translatePath(os.path.join('special://home','addons','packages'))
        dp = xbmcgui.DialogProgress() 
        dp.create("Eminence zeev - הפעלה ראשונה","מתקין הגדרת נגנים עבור הרחבת  Quasar ",'','רץ בפתיחה ראשונה בלבד') 
        lib = os.path.join(path,name + '.zip')
        try: os.remove(lib)
        except: pass
        downloadMetaSettings(url,lib,dp)
        time.sleep(2)
        #dp.update(0,"","Installing selections.....")
        all(lib,xbmc.translatePath('special://home'),'')
        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.executebuiltin("UpdateAddonRepos")

def GetSaltsSettings(name,url):
        path = xbmc.translatePath(os.path.join('special://home','addons','packages'))
        dp = xbmcgui.DialogProgress() 
        dp.create("Eminence zeev - הפעלה ראשונה","מתקין הגדרת נגנים עבור הרחבת  Salts ",'','רץ בפתיחה ראשונה בלבד') 
        lib = os.path.join(path,name + '.zip')
        try: os.remove(lib)
        except: pass
        downloadMetaSettings(url,lib,dp)
        time.sleep(2)
        #dp.update(0,"","Installing selections.....")
        all(lib,xbmc.translatePath('special://home'),'')
        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.executebuiltin("UpdateAddonRepos")

def installMetaSettings():
    if not os.path.exists(metasettingsPath):
            GetMetaSettings('MetaSettings',MetaSettingsUrl)

def installQuasarSettings():
    if not os.path.exists(quasarsettingsPath):
            GetQuasarSettings('QuasarSettings',QuasarSettingsUrl)

def installSaltsSettings():
    if not os.path.exists(saltssettingsPath):
            GetSaltsSettings('SaltsSettings',SaltsSettingsUrl)	
			
def startup2():    
    installMetaSettings()
    installSaltsSettings()
    installQuasarSettings() 			