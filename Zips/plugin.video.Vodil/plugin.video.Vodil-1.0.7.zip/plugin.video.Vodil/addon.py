# -*- coding: utf-8 -*-
import urllib,urllib2,re,xbmcplugin,xbmcgui,os,sys,datetime
from resources.lib.common_variables import *
from resources.lib.directory import *
from resources.lib.youtubewrapper import *
from resources.lib.watched import * 

fanart = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.Vodil', 'fanart.jpg'))
art = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.Vodil/resources/img', ''))

def CATEGORIES():
        addDir('דוקומנטרי','url',11,art + 'documentary.jpg')
        addDir('מוסיקה','url',13,art + 'Music.png')
        addDir('הופעות חיות','url',16,art + 'liveshows.png')
        addDir('ילדים','url',12,art + 'kids.png')
        addDir('אוכל ובישול','url',17,art + 'cooking.png')
        addDir('טיולים','url',14,art + 'travel.png')
        addDir('לייף סטייל','url',10,art + 'lifestyle.png') 
        addDir('ספורט (בבניה)','url',15,art + 'Sports.png')


def kids():
        addDir('הצגות לילדים','PLnzhIyrsnB5Zu0JR6EraEXji-d3sW6o2f',1,art + '30021.jpg')
        addDir('סרטים לילדים מדובב + מתורגם','PLnzhIyrsnB5ZHtALtuMGstpsfQFG8wLZE',1,art + 'animals.jpg')
        addDir('קלטות לילדים','PLnzhIyrsnB5a38kh3wYOpPRp68IkZplEU',1,art + 'tif.jpg')
        addDir('יובל המבולבל','PLnzhIyrsnB5YV0x8-eK-2b1CQcEOsQh7j',1,art + '30022.png')
        addDir('דוד חיים','PLnzhIyrsnB5Yjwnu5aTAi2gtZhudsPHPz',1,art + '30024.jpg')
        addDir('מיכל הקטנה','PLnzhIyrsnB5ZZEwjUbKm8Aw5mbI-RfFho',1,art + '30027.jpg')
        addDir('רינת','PLnzhIyrsnB5ZQ_D3eWkQ_7EvN44tB4E5b',1,art + '30028.jpg')
        addDir('פסטיגל','PLnzhIyrsnB5Z6uBvYYnILEv36z0F5j4fj',1,art + '30029.jpg')
        addDir('ערוץ גוניור','PL3432ABAC840E3DF3',18,art + '30030.jpg')
        addDir('ניק גוניור','PLbrxg_e8MbbF-psMIds86ndWuTehx4kQS',19,art + '30031.jpg')
        addDir('ניקלודאון','PLtXcJHjzQOdOJyKUf4N_im5szCADvUbb_',20,art + '30032.jpg')
        addDir('לוגי','PLtXcJHjzQOdOJyKUf4N_im5szCADvUbb_',21,art + '30033.jpg')
        addDir('הופ','PLeagipoZmyfmBwqCrCc8p7cE6QdLes-eL',22,art + 'hop.png')
        addDir('הופ ילדות ישראלית','PLrhuB2KrXOjikfPLJhTmz2qKDkltz9L8Y',23,art + 'hopy.jpg')
        addDir('לולי','PLqcNVz8UuCsLhpzTjL0JGj3YuMyWWd5Ug',24,art + 'luly.jpg')
        addDir('בייבי','PLsFmiuNwu758huWLmxTM4NCln7tbqJDPn',25,art + 'baby.jpg')
        addDir('הוט ילדים','PLtfPnJye9L3dxlbWP7OlJH-_yI3PYsh9r',26,art + 'HOTVOD.png')
        addDir('ערוץ הילדים','PLeagipoZmyfkWkyetCWsJMGy8yBvHdJs-',27,art + 'kidstv.png')
        addDir('חינוכית לילדים','PLeagipoZmyfn9MhKB9Smgqob8CLNiaA51',28,art + '23.jpg')
        addDir('ערוץ זום','PLS3SOlSTtJcDe-vQ-T46r_cB1U_ENAuKF',29,art + 'zoom.jpg')
        addDir('דיסני גוניור','PLeagipoZmyfl46t2ABPQitVy1V7qu2vrG',30,art + 'dsjr.jpg')	

def junior():
        addDir('קופיקו עונה 1','PLR7DTcU2p0QhDzYbbniDNwSbXUM_p6N3f',1,art + '30030.jpg')
        addDir('קופיקו עונה 2','PLR7DTcU2p0QgEdLPHhrhKtxElvYVrseAQ',1,art + '30030.jpg')
        addDir('קופיקו עונה 3','PLR7DTcU2p0QhNGUffSgu8_5dP3lnOGZTx',1,art + '30030.jpg')
        addDir('הפיראט המהיר','PLR7DTcU2p0Qirvpu8HPR2GUCLJmXrn9dJ',1,art + '30030.jpg')
        addDir('הנעלמים','PLR7DTcU2p0Qh4o44FETppW3n4vQCQGqsk',1,art + '30030.jpg')
        addDir('דוח דלעת','PLR7DTcU2p0QhuQU-SWBGtywN6Zt1bapZt',1,art + '30030.jpg')
        addDir('ספיד רייסר','PLR7DTcU2p0QjzH9muKiw1eTbp0aU3hB63',1,art + '30030.jpg')
        addDir('וולברין והאקס מן','PLR7DTcU2p0QhGsv3LuA3GnCJWjoPBCafl',1,art + '30030.jpg')
        addDir('החתולים הסמוראיים','PLR7DTcU2p0QhPmznEmitRHkv5RcUG3E-s',1,art + '30030.jpg')
        addDir('רוי בוי','PLR7DTcU2p0Qg8pxiEld0Fg3K2Bd8gTKw5',1,art + '30030.jpg')
        addDir('בארץ הקטקטים','PLR7DTcU2p0Qg5sF-jE09YnRymKba8N8l_',1,art + '30030.jpg')
        addDir('משטרת האגדות','PLR7DTcU2p0QiaEmc56lGHMpxW4ladE93X',1,art + '30030.jpg')
        addDir('סנדוקאן','PLR7DTcU2p0QgWYVQap5zPK0MkwJizYku_',1,art + '30030.jpg')
		
def dsjunior():
        addDir('ארמון החיות','PLVwL64lSxWWy8lQUurv6EHnQHXN45Di98',1,art + 'dsjr.jpg')
        addDir('הנסיכה סופיה הראשונה','PLVwL64lSxWWyAUC6Bv-GAbdgQAv3CuCrr',1,art + 'dsjr.jpg')
        addDir('הסרטים המצויירים של מיני ','PLVwL64lSxWWw21D3vaqKMxNOXTO82t1je',1,art + 'dsjr.jpg')
        addDir('ספיישל להיות פיראט','PLVwL64lSxWWzCmfvd65mBVKGX0VMFIEM7',1,art + 'dsjr.jpg')
        addDir('התעמלות עם מיקי מאוס','PLVwL64lSxWWwLsl52oUSphP6zSbbvQu_h',1,art + 'dsjr.jpg')
        addDir('דוק רופאת צעצועים','PLVwL64lSxWWyRD2CIOc5qkXUuSWSsyuRh',1,art + 'dsjr.jpg')
        addDir('הרגעים הגדולים של סטאר ','PLRKLm5GvuZVIv7NoJvoBrlAlOYaatpzqM',1,art + 'dsjr.jpg')
        addDir('היורשים - בית ספר של סודות','PLRKLm5GvuZVJq1moobQvXZUHMM943qAWP',1,art + 'dsjr.jpg')
        
def zoom():
        addDir('ציקה ומפירו','PLnzhIyrsnB5YoLZMevyWHS4lhnFB2yIH-',1,art + 'zoom.jpg')
        addDir('סוסי פרא','PL9FUtLp-Tfr3vR1EJa04KIDYskHfpsaQp',1,art + 'zoom.jpg')
        addDir('מועדון החנונים','PLKMFPiSCwUk0myYc1Z8oPLGO6hXJdf5uv',1,art + 'zoom.jpg')
        addDir('סופר סטרייקה','PLnzhIyrsnB5ZoulWt_5tVF2MaySwu-1Vm',1,art + 'zoom.jpg')
        addDir('צימה','PLnzhIyrsnB5at3Uw3KWWCzVYUOCD6aYy9',1,art + 'zoom.jpg')
        addDir('מועדון החנונים','PLKMFPiSCwUk22xxgMwcNShgeBYNSfotbB',1,art + 'zoom.jpg')
        addDir('דיגימון','PLKMFPiSCwUk2AWPSN0CngtMfiB8oFWZwX',1,art + 'zoom.jpg')
        addDir('איטי ועצבני','PLKMFPiSCwUk08zM6SlJ3RrCu2_zdReijH',1,art + 'zoom.jpg')
        addDir('פאוור  ריינגרס','PLKMFPiSCwUk01oKz850en3WtD80zdmGus',1,art + 'zoom.jpg')
        
def ch23():
        addDir('היה היה','PLPO4_vX2WeIV8QjNMKILbbGXwxY0H3jgZ',1,art + '23.jpg')
        addDir('חדשות מהעבר עונה 3','PLth1a195qHsgnf978kWlEqU3IWuM2XnRI',1,art + '23.jpg')
        addDir('חדשות התנך','PLth1a195qHsgd5DCakz5w30jJ2_wsD9uv',1,art + '23.jpg')
        addDir('החפרנים עונה 3','PLth1a195qHsh6M7Js4DzJrIoa9_lMB4Zp',1,art + '23.jpg')
        addDir('בוא נתערב','PLth1a195qHsgHRikWwcJcTjpD_Ks4qYeU',1,art + '23.jpg')
        addDir('בחצר של פופיק','PLth1a195qHsjUfGFAG3FYPa361qHF7wze',1,art + '23.jpg')
        addDir('כנסת נכבדה','PLth1a195qHsiN_6THGph_Kl3_hwQPq4vE',1,art + '23.jpg')
        addDir('קישקשתא בדרכים','PLth1a195qHsjLDoU-UCLFZrCQCd8ulef_',1,art + '23.jpg')
        addDir('שוסטר ושוסטר','PLth1a195qHshFOAU_eVupbzfvNkhcZ4pq',1,art + '23.jpg')
        addDir('כאן ואומן','PLth1a195qHsjuXR49nz70tgdT-g1nroZR',1,art + '23.jpg')
        addDir('חדשות מהעבר מהדורה עולמית','PLth1a195qHshoshAzTBxywa88VxYFB5ne',1,art + '23.jpg')
        addDir('מה הסיפור? עונה 2','PLth1a195qHsg6eDer1tNg4OAv5CmLOFhv',1,art + '23.jpg')
        addDir('מה זה מוזה במעבדה עונה 2 ','PLth1a195qHsj20lXv4QqTQ7kb2RLoGxY8',1,art + '23.jpg')
        addDir('חיות במה בהופעה ','PLth1a195qHsia6PoVqxkhSajNlBszZ4wu',1,art + '23.jpg')
        addDir('דן ומוזלי עונה 2','PLth1a195qHsh2JB7l8Y-0B8RKTzKeLTzI',1,art + '23.jpg')
        addDir('גלילאו עונה 5 ','PLth1a195qHsigShKnT9DsIyKxcTBQ70Tf',1,art + '23.jpg')
        addDir('דן ומוזלי','PLth1a195qHsg1IITJcYXjfsNCdbRn3XTD',1,art + '23.jpg')		
		
def kidstv():
        addDir('הכל טום','PLstSEvEmr9e8wuM076jsnSbM6HEdLjmfz',1,art + 'kidstv.png')
        addDir('ברחובות שלנו','PLstSEvEmr9e-2ucQ38nu31Ms1qJPlVHcS',1,art + 'kidstv.png')
        addDir('הבנים והבנות','PLnzhIyrsnB5ZjJfepTibnFqEG8BD6ZML4',1,art + 'kidstv.png')
        addDir('שוברי גלים','PLnzhIyrsnB5bRzOyHnZgx7yHzOBAXz79L',1,art + 'kidstv.png')
        addDir('נדחפים','PLstSEvEmr9e-7DxpPTuIbRjIbFCMcY7YZ',1,art + 'kidstv.png')
        addDir('פרויקט הלהקה','PLnzhIyrsnB5ZwJDhjWM0bK-D4WFDR1jCQ',1,art + 'kidstv.png')
        addDir('ששטוס','PL7c4Q2VJu8RPYg1H-Cc005Pydh-nUNooD',1,art + 'kidstv.png')
        addDir('השמיניה','PLdHb9F0cRmPwtckIQ4LtKH_ZZOtTYoxC7',1,art + 'kidstv.png')
        addDir('בית ספר למוזיקה','PLF583DE56321F34CF',1,art + 'kidstv.png')
        
def hot():
        addDir('סוסי פרא','PL419YR22ubLCkWDoe9rdRvkeF3UD259Wq',1,art + 'HOTVOD.png')
        addDir('גאליס','PLnzhIyrsnB5bxl8sjsRDcrkodmEF08lJl',1,art + 'HOTVOD.png')
        addDir('מועדון החנונים','PLnzhIyrsnB5bmIlwndIpo7tuLJZT4dnPl',1,art + 'HOTVOD.png')
        addDir('הקלמרים','PLnzhIyrsnB5YCnG2GryC_jFjDLCZoMLax',1,art + 'HOTVOD.png')
        addDir('הפיגמות','PLnzhIyrsnB5ZtO6UnIyktQIs4_Kysgfki',1,art + 'HOTVOD.png')
        addDir('שכונה','PL419YR22ubLAeiTiDZ3oHDtPmD54vi2vB',1,art + 'HOTVOD.png')
        addDir('גיא ביער החיות','PL419YR22ubLD1JcHPAtU_KFQ-53xOZ9YP',1,art + 'HOTVOD.png')
        addDir('החוף של רינת - 2','PL419YR22ubLB2k8pelTCjEcf9vtOdJPMX',1,art + 'HOTVOD.png')
        addDir('עמרי והפיה יעלי','PL419YR22ubLBPUYYOTxv3y4J4jadrvBDM',1,art + 'HOTVOD.png')
        addDir('חיפזון וזהירון ','PL419YR22ubLCBKso-lZI46QeMOajbJo1K',1,art + 'HOTVOD.png')
        addDir('החוף של רינת - עונה 1','PL419YR22ubLDmN4nWRYdtXsPEqfUcwXTu',1,art + 'HOTVOD.png')
        addDir('רוני וקשיו','PLFC30D9236B6C1D89',1,art + 'HOTVOD.png')
        addDir('הגרוטיאדה','PLD410CE40090B6F46',1,art + 'HOTVOD.png')	
        addDir('מותק של יומולדת','PL19F7B03ACE78D040',1,art + 'HOTVOD.png')
        addDir('מלכת קסמים','PL252279467C3A6572',1,art + 'HOTVOD.png')

		
def hop():
        addDir('סמי הכבאי','PLnzhIyrsnB5bh8-A2Upur_ksxi5X4YHz-',1,art + 'hop.png')
        addDir('פיטר הארנב','PLnzhIyrsnB5bCmetasVBSsjyD3ImYwud0',1,art + 'hop.png')
        addDir('מספרי משימה','PLnzhIyrsnB5Z0Fh-AJZchZDODCczCQAfK',1,art + 'hop.png')
        addDir('חבורת החצר','PLnzhIyrsnB5Zf4Ke3bQVzXXscfGNC7sG2',1,art + 'hop.png')
        addDir('מיכל הקטנה הופ','PLnzhIyrsnB5ZXcKexGucWUf2ifAd5dEQj',1,art + 'hop.png')
        addDir('מר עגבניה יובל המבולבל','PLfcYs4SRZfuLibKBZbJKnGpbPf9XxtRWZ',1,art + 'hop.png')
        addDir('יובל המבולבל','PLfcYs4SRZfuIrU-AvQvAoJ01gW-EnlfHw',1,art + 'hop.png')
        addDir('בוב הבנאי','PL_8KXLhQVQMK80XCn7g3qVj7RwhrwiGHG',1,art + 'hop.png')
        addDir('מולי וצומי','PLfcYs4SRZfuJHmb8y_BpUpzAsm1guoAlK',1,art + 'hop.png')
        addDir('חבורת חשבונבונים','PLfcYs4SRZfuLfZHSFxkaT55Hd6nw5N2hi',1,art + 'hop.png')
        addDir('היקום שלי','PLfcYs4SRZfuLc0EsDe3Hu3o98Dsv_6m9M',1,art + 'hop.png')
        addDir('חזרה לגן ולבית הספר','PLfcYs4SRZfuJSXTLmVphH2f7bDvs-6p6u',1,art + 'hop.png')
        addDir('החיוך של רוזי','PLfcYs4SRZfuKA9uxEK0kvYZNOObplk5jK',1,art + 'hop.png')	

def hopy():
        addDir('שירים ברצף לילדים','PL6jaO-hu0IvypWmNRJxwG8JP9S2PoDdq-',1,art + 'hopy.jpg')
        addDir('שירי נעמי שמר','PL6jaO-hu0Ivw-eYL2Usw_I1UAfQfTXgL2',1,art + 'hopy.jpg')
        addDir('שירי אריק איינשטיין - שירים ילדים','PL6jaO-hu0Ivz2bnvMiXTH1o--x5XQgxN2',1,art + 'hopy.jpg')
        addDir('שירי לאה גולדברג ','PL6jaO-hu0IvxLOnGOzzxXbjOR66OdFRO5',1,art + 'hopy.jpg')
        addDir('גילי בא לבקר','PL6jaO-hu0IvwPjfkrAicOe1bq-orEN1TT',1,art + 'hopy.jpg')
        addDir('שירי חיות לילדים','PL6jaO-hu0IvznDFo8JyQRHRUP5l6DoxT2',1,art + 'hopy.jpg')
        addDir('שירים לפעוטות','PL6jaO-hu0IvydJtUigNLeFFUq1vXZtCk3',1,art + 'hopy.jpg')
        addDir('שירים לילדים לקראת השינה','PL6jaO-hu0IvznQlhRRKBY6M_ykDXxdB0r',1,art + 'hopy.jpg')
        addDir('דפנה ואורי - שירים ישראלים','PL6jaO-hu0IvyE-cdcwbQ8bhxZnUr2jflq',1,art + 'hopy.jpg')
       				
def nickjunior():
        addDir('מגלים עם דורה','PLnzhIyrsnB5Y7_fxFIhYzmMggxTnl5kAv',1,art + '30031.jpg')
        addDir('תמר הבלשית','PLPWc8VdaIIsAki2FqbtHQ7xW3zIMCTL3d',1,art + '30031.jpg')
        addDir('ענבלי בא לי','PLPWc8VdaIIsB2vKN57J-hZAk8nqGpa4EF',1,art + '30031.jpg')
        addDir('זמן לזוז','PLPWc8VdaIIsDYbIQJMDX4usMYw7pYmPxj',1,art + '30031.jpg')
        addDir('הסוד של מיה','PLPWc8VdaIIsCGEVOC2iJxnWNEjI13xbnA',1,art + '30031.jpg')
        addDir('עולמו הקסום של מקס','PLPWc8VdaIIsCeVQhASYBNmykK4gKh0DCe',1,art + '30031.jpg')
        addDir('מר למה וגברת ככה','PLPWc8VdaIIsC8iEN7EhY46jmy93imkpHI',1,art + '30031.jpg')
        addDir('משפחת יומולדת','PLPWc8VdaIIsBOUPxtM2CD7yGs1D8NCM_Z',1,art + '30031.jpg')
        addDir('שטויות בחדשות ','PLPWc8VdaIIsBzxaUfj3smv1tJ8sKQXwrW',1,art + '30031.jpg')
        addDir('בגינה של לין','PLPWc8VdaIIsDcjHMTBavJG-Rm8p0wvvW_',1,art + '30031.jpg')
        addDir('סיפורי פיות','PLPWc8VdaIIsD8YvtRkkqjYC5SF7TKvAcM',1,art + '30031.jpg')
        addDir('יצירה בקצרה','PLPWc8VdaIIsC0SPM0_dgOVIDn5vcCH8Ti',1,art + '30031.jpg')
        addDir('שלוש ארבע לעבודה','PLPWc8VdaIIsASIzs8TcS3FFYEL68jBPWO',1,art + '30031.jpg')
        addDir('רוני וקשיו','PLPWc8VdaIIsDPb04SHd5fzzqYt3FtmWs-',1,art + 'Cartoons.png')
		
def luly():
        addDir('לולי ספיישלים - פרקים מלאים ברצף','PLTleo-h9TFqLYSNebLcKWr2outn2xYRhe',1,art + 'luly.jpg')
        addDir('טלטאביז','PLCVlyUabAQX0baRcL13edNd1zBeqLuoaV',1,art + 'luly.jpg')
        addDir('מיילו','PLTleo-h9TFqJI6GrNCJO9yjyXbZHS9X-F',1,art + 'luly.jpg')
        addDir('טוקטוק','PLTleo-h9TFqKkr82pGJe-bk1pMMxFg_b-',1,art + 'luly.jpg')
        addDir('צרלי ודודו','PLTleo-h9TFqK3NlYz7T3fz6XGRfTVk2FH',1,art + 'luly.jpg')
        addDir('חיות בערוץ לולי','PLTleo-h9TFqI2CFuWeFA-Q2Bu3BBHdXqv',1,art + 'luly.jpg')
        addDir('לולי למתחילים','PLTleo-h9TFqKzWTiRE8-uIG8cWqSu0FW8',1,art + 'luly.jpg')
        addDir('קוקו הארנב','PLnzhIyrsnB5bntEbuvQNa4VqJ0dOaOVtD',1,art + 'luly.jpg')
        addDir('חבורת אבאדס','PLTleo-h9TFqLym2Yg3-l_TJeqigJFstsE',1,art + 'luly.jpg')
        addDir('בומבה','PLTleo-h9TFqLkb8a4Y9aeuZUH0W436ah7',1,art + 'luly.jpg')
        addDir('בונים מבלונים','PLTleo-h9TFqK-0raN5AabE_YjlNsLj-hb',1,art + 'luly.jpg')
        addDir('להלילו','PLTleo-h9TFqJsNpiGgyKbJyqjBJxyBBZe',1,art + 'luly.jpg')

def baby():       
        addDir('ערוץ בייבי - תוכניות ברצף','PLErYJg2XgxyWqQlU1CqCdPs15WhnAzzwb',1,art + 'baby.jpg')
        addDir('שירים ישראליים לילדים','PLErYJg2XgxyXTMAJvmFXoW6Qe66Ztw0Fk',1,art + 'baby.jpg')
        addDir('קיץ עם ערוץ בייבי','PLErYJg2XgxyWdetl6GmsKjp4hIlaR6BDl',1,art + 'baby.jpg')
        addDir('פרקים מיוחדים ליום ההולדת','PLErYJg2XgxyWWl7sL3Oh25LxgXe5Vgpwz',1,art + 'baby.jpg')
        addDir('חגי ישראל עם רינת גבאי ומימי','PLErYJg2XgxyXgomy8FhI8SM23jHsp7y7o',1,art + 'baby.jpg')
        addDir('חורף עם ערוץ בייבי','PLErYJg2XgxyV4DL2r3vpo74zeJuWa8K1x',1,art + 'baby.jpg')
        addDir('אוצר מילים עם נוני','PLErYJg2XgxyXmgk6cyROtlJh2g-Fk_T6n',1,art + 'baby.jpg')
        addDir('רינת גבאי ומימי בארץ המילים','PLErYJg2XgxyX7c9LjwlY22F3cjpI5h6V_',1,art + 'baby.jpg')
        addDir('דרקו ותולי','PLErYJg2XgxyVJhg76kIibughL6QiHgN2-',1,art + 'baby.jpg')
        addDir('אוליבר','PLErYJg2XgxyX1gmsKze-1WjpDoNefNYJD',1,art + 'baby.jpg')
        addDir('מתכוננים לשינה עם ערוץ בייבי','PLErYJg2XgxyVYzsbPxH2dzhlWLs9sWGTa',1,art + 'baby.jpg')		
        addDir('רינת גבאי בעולם האגדות','PLErYJg2XgxyWiffjko4BQmExqDdR6-C4v',1,art + 'baby.jpg')
		
def logy():
        addDir('היה היה','PL7FRY7ROxqHQQFHpxmJ6r-xiB1K0BwGdu',1,art + '30033.jpg')
        addDir('אין חיה כזאת - ממושה','PLnzhIyrsnB5bFcWJAIfnnkPVcu_Owmagv',1,art + '30033.jpg')
        addDir('קני הכריש','PLD_Y4wLedlhqRCLLpVWlqg6g7k9F8t98J',1,art + '30033.jpg')
        addDir('אוטובוס הקסמים','PLnzhIyrsnB5ajOezFw2wCpHCg1biIzYGa',1,art + '30033.jpg')
        addDir('הובס ספר הקסמים הגדול','PLnzhIyrsnB5Y9PQ5k5jG0fr1V3LJTuFHN',1,art + '30033.jpg')
        addDir('המובילים עונה 1','PL-SBsAk8heRmm43KBeVhC9h6R6wCUSW7j',1,art + '30033.jpg')
        addDir('המובילים עונה 2','PLBaGngHK8wj1OxzO6P3ouBUulIG4fijkG',1,art + '30033.jpg')
        addDir('המובילים עונה 3','PLBGBC8WmVUB9xGVomRmpLtFAsrbBhRHx0',1,art + '30033.jpg')
        addDir('כח מילולית','PLnzhIyrsnB5ZUB06GBVvhZ93hPaoy9Mv1',1,art + '30033.jpg')		

def nicklodeon():
        addDir('הצחוקייה 1-4: פרקים מלאים','PLuQCYUv97StSnZGTUoMyIjbFdAACRCxKV',1,art + '30032.jpg')
        addDir('צמפיונסיק','PLuQCYUv97StRAe0OQOvWUBejgQVAjrucA',1,art + '30032.jpg')
        addDir('גן חיות 1 + 2','PLuQCYUv97StTP1kioc4cGBUkdPrktt8Pz',1,art + '30032.jpg')
        addDir('גן חיות עונה 3','PLuQCYUv97StQfg1CrmkR5ChUnu6q1X5Hj',1,art + '30032.jpg')
        addDir('משפחת כספי','PLuQCYUv97StRNroygQpznlYXzyvob8aDJ',1,art + '30032.jpg')
        addDir('שכונה','PLuQCYUv97StQ1q3po2cwh48H6LOSZbjaM',1,art + '30032.jpg')
        addDir('הצחוקייה סופרסטארז','PLuQCYUv97StQ5w1484WOSYjwFfhiQsnPy',1,art + '30032.jpg')
        addDir('הצחוקייה - קצרצרים, עונות 3-1','PLuQCYUv97StTBH8qBwHzw12DHe7Zn78Qx',1,art + '30032.jpg')
        addDir('שכונה','PLuQCYUv97StR0o1N7zfbpobVVwev0sx91',1,art + '30032.jpg')
        addDir('יפניק','PLuQCYUv97StS-YtE8BYNUpLIxKrGOBAe6',1,art + '30032.jpg')
        addDir('סופר שטותניק','PLuQCYUv97StRk-DsmuAL0ptZPJ9ATkguV',1,art + '30032.jpg')
        addDir('חבורת הספסל האחורי','PLuQCYUv97StTLZK9Zicyj4qfyiVh0DbkN',1,art + '30032.jpg')
        addDir('קיץ דיגיטלי','PLuQCYUv97StT2i_JrYVDy2cVTW1Gtmp9s',1,art + '30032.jpg')
		
def lifestyle():       
        addDir(''+translate(10013)+'','PLCXKcf_9F-9ILiz6gapk-g6eRVczIinXn',1,art + 'lifestyle.png')
        addDir(''+translate(10014)+'','PLvw1iwpJo48E7MsgyxQwthpjYdMJV4a2l',1,art + 'lifestyle.png')
        addDir(''+translate(10015)+'','PLBQgA3Kndk7eYrJwHej6Swx-nryBmN52V',1,art + 'lifestyle.png')
        addDir(''+translate(10016)+'','PLK_DOFD1-caZyw7DH1PeghrCeAa0RXKGl',1,art + 'lifestyle.png')
        addDir(''+translate(10017)+'','PLE403X8vX2i1nabZsuGAZT7KaJTtX6_iu',1,art + 'lifestyle.png')
        addDir(''+translate(10018)+'','PLPJTnhnYa-pOndAB5TU2A8qEpUguaxj5U',1,art + 'lifestyle.png')
        addDir(''+translate(10019)+'','PL40DAF9063E60BD47',1,art + 'lifestyle.png')
        addDir(''+translate(10012)+'','PLP1X5PjaY0cw-jNeYM5itPwNC89L6K6ee',1,art + 'lifestyle.png')
        addDir(''+translate(10020)+'','PLnzhIyrsnB5b2kjwaZOLmoGPBXU4IPpXi',1,art + 'lifestyle.png')
        addDir(''+translate(10021)+'','PLoCBhUDrfgwpkBF9LGJzjcdqrA5BzGnn1',1,art + 'lifestyle.png')
        addDir(''+translate(10023)+'','PLWSwSEhBdIBKsVqaZn9PwebkLguJX3vSM',1,art + 'lifestyle.png')
        addDir(''+translate(10024)+'','PLoCBhUDrfgwqhdtQo2pMtMr4a3i3FLjOy',1,art + 'lifestyle.png')
        addDir(''+translate(10025)+'','PLYMK_Nbs-rsupx1SLcgZFXnfy7HZ3KRoN',1,art + 'lifestyle.png')
        addDir(''+translate(10026)+'','PLKUX44R3MbuR3sX61i9QiwnOBr61tEMc_',1,art + 'lifestyle.png')
        addDir(''+translate(10027)+'','PLE0ZXwRBc5iNxdziR3nGtfZoi11p2y0hO',1,art + 'lifestyle.png')
        addDir(''+translate(10028)+'','PLP3V-LOuN7YX5yIWumBvrDGJ_Dt355Wd7',1,art + 'lifestyle.png')
        addDir(''+translate(10029)+'','PLE403X8vX2i12ajSfJmY9MZ2tRfWwA11X',1,art + 'lifestyle.png')

def documentary():
        addDir('דוקו בעברית','PL-VGVK6cqjoj6Aeyi2x7yQqo0S9Pq8CkZ',1,art + 'documentary.jpg')
        addDir('סרטוני טבע בעברית','PLnzhIyrsnB5Y8Ymf2ryG-LlX0DxK0JD5N',1,art + 'documentary.jpg')
        addDir('דוקו אנשים ותופעות','PL-VGVK6cqjog4X0-J49ZyeKQ7SRFMhgVz',1,art + 'documentary.jpg')		
        addDir('חוצה ישראל','PL3n39NB10sYkxOj0jlAWVtxGJBkMosU1K',1,art + 'documentary.jpg')
        addDir('דוקומנטרי עם רינו צרור','PLnzhIyrsnB5ahqRF_z2KwVFffa65NbDyR',1,art + 'documentary.jpg')
        addDir('טבע לילדים בעברית','PLXvO_l8W5G9mTvi47UBykJUtf5pjygYMK',1,art + 'documentary.jpg')
        addDir('סרטונים נבחרים נשיונל גאוגרפיק','PLivjPDlt6ApQ8vBgHkeEjeRJjzqUGv9dV',1,art + 'documentary.jpg')
        addDir('סרטונים פופולריים סרטי טבע תיעודיים','PL5o3ll3G4acxgDMSO7JXvDsosQ-UDPL6n',1,art + 'documentary.jpg')
        addDir('נשיונל גיאוגרפיק','PLnzhIyrsnB5bP-t6Q6jfKANduI0KyxzkW',1,art + 'documentary.jpg')
        addDir('Net Geo Wild','PLnzhIyrsnB5aCGBlzR9RPhX3xH3YZN8DG',1,art + 'documentary.jpg')
        addDir('דיסקברי','PLnzhIyrsnB5adVQsQo5fuO-MwVHOGP9uN',1,art + 'documentary.jpg')
        addDir('דוקומנטרי BBC','PLnzhIyrsnB5ZMAgPLxwup_x3uxI2cmpnl',1,art + 'documentary.jpg')
        addDir('סרטוני טבע HD','PLCF042F294768BFD1',1,art + 'documentary.jpg')
        addDir('טבע וחיות בר HD','PLql7ZywaMwm3k61EPg8RAa0EJxKT9QcRj',1,art + 'documentary.jpg')
        addDir('אוקיינוס','PLnzhIyrsnB5a7ippNlF0uUoqt6-w3dT55',1,art + 'documentary.jpg')
        addDir('אפריקה','PLnzhIyrsnB5bmxEqQVckOIP2xJEo34ULg',1,art + 'documentary.jpg')
        addDir('רוסיה הפראית','PLql7ZywaMwm0qsDq7eziLHbtmHkD77aCj',1,art + 'documentary.jpg')
        addDir('מדע','PLnzhIyrsnB5ao4_fR_dwQCjGPt9b6Y5NV',1,art + 'documentary.jpg')
        addDir('דינוזאורים','PLnzhIyrsnB5bxAwKewvF4q8ORDR9HysZc',1,art + 'documentary.jpg')
        addDir('חיות קטלניות','PLnzhIyrsnB5Yh0sE2zKFBvKAvoOoqsaVK',1,art + 'documentary.jpg')
        addDir('כרישים','PLnzhIyrsnB5a5kuDD_nUoanZIbkfMGFOC',1,art + 'documentary.jpg')
        addDir('נחשים','PLnzhIyrsnB5Zrmtwl7Mcsd25iz2ZvnzpE',1,art + 'documentary.jpg')        
        addDir('ציפורים','PLnzhIyrsnB5a-V6CL6AvGykvFc-BkkAmW',1,art + 'documentary.jpg')
        addDir('תנינים','PLnzhIyrsnB5YPDK-se-BkGWaDjPER-0jp',1,art + 'documentary.jpg')
        addDir('דובים','PLnzhIyrsnB5ZuhAQyz6kzcmlAl_K18Jvl',1,art + 'documentary.jpg')
        addDir('אריות','PLnzhIyrsnB5bFPCKp6A5afJiE0S1-s_C6',1,art + 'documentary.jpg')
        addDir('איך זה פועל','PLLgqOez346ZPcqnmLsDkqr0kPjuRz5Rjo',1,art + 'documentary.jpg')
        addDir('חוצנים','PLnzhIyrsnB5anK8nEb1NZAz9RHI9vmsOX',1,art + 'documentary.jpg')
        addDir('קונספירציות מתורגם','PLnzhIyrsnB5b2OK0deM0-QnSFc4___ePC',1,art + 'documentary.jpg')
        addDir('קונספירציות לועזית','PLnzhIyrsnB5YDJn_Au9XLvNgdwoRIxD4P',1,art + 'documentary.jpg')
        addDir('מערכת השמש','PLnzhIyrsnB5bAenSifBCSE6eO_HuWrHRd',1,art + 'documentary.jpg')
        addDir('חורים שחורים','PLIkasLQ_GYaEvfZ9RAvkLtqR1BUYRaBZt',1,art + 'documentary.jpg')
        addDir('סיפורים מעוררי השראה','PLUkdT9ljJ1cYE-Mxn43WRf_0Gq4oWa-QD',1,art + 'documentary.jpg')		
        addDir('חיות מחמד יוצאות דופן','PLUkdT9ljJ1caovAwonqPel9hYzk8V1j4l',1,art + 'documentary.jpg')		
        addDir('ערוץ ההיסטוריה - תרבויות עתיקות','PL8RzKSpOzIx1476Y9pVVSE1dkFA0otm-Q',1,art + 'documentary.jpg')
        addDir('ערוץ ההיסטוריה DECISIVE BATTLES','PL3H6z037pboH81MoHl8zcbugf2onvFcDc',1,art + 'documentary.jpg')
        addDir('ערוץ ההיסטוריה THE REAL WILD WEST','PL3H6z037pboG9_flx9II9XMO5VE_1qHtR',1,art + 'documentary.jpg')
        addDir('ערוץ ההיסטוריה The Conquerors','PLSBILXkL0K2tuApKAbXqwkoRgkq2ixifw',1,art + 'documentary.jpg')
		
def Music():
        addDir('שירים ישראלים חדשים','PLD_zAoRa9UcA4U7jHXTx3hDF3om7zM5jd',1,art + 'Music.png')
        addDir('מוסיקה ישראלית איכותית','PLzzwAvFoE3KfG0eR0kCdUjEiEbOIUpvZb',1,art + 'Music.png')
        addDir('שירים ישראליים מכל הזמנים','PL3AB9B8D3C7E026A5',1,art + 'Music.png')
        addDir('שירים ישראליים מרגשים','PLryjW6BWLS1Q_xeVOlPfXJF4S3G0purex',1,art + 'Music.png')
        addDir('דאנס מזרחי רמיקסים','PLnzhIyrsnB5a6p88BZbF6yzEtA_8VXW73',1,art + 'Music.png')
        addDir('מזרחית קצבית','PLgXzOr585f6Rh30c143sE_YzV7KE9mqkB',1,art + 'Music.png')
        addDir('סרטונים חדשים','PLrEnWoR732-D67iteOI6DPdJH1opjAuJt',1,art + 'Music.png')
        addDir('סרטוני וידאו פופולריים','PLFgquLnL59alCl_2TQvOiD5Vgm1hCaGSI',1,art + 'Music.png')
        addDir('Billboard 2016 טופ','PL55713C70BA91BD6E',1,art + 'Music.png')
        addDir('להיטי mtv 2016','PLySPrRhsyUwryAVNyHoPyOmZAAw_nFM_z',1,art + 'Music.png')
        addDir('להיטים חדשים vevo 2016','PLvFYFNbi-IBFeP5ALr50hoOmKiYRMvzUq',1,art + 'Music.png')
        addDir('הנצפים ביותר בכל הזמנים vevo','PLirAqAtl_h2pRAtj2DgTa3uWIZ3-0LKTA',1,art + 'Music.png')
        addDir('רצועות מובילות – מוסיקת פופ','PLDcnymzs18LVXfO_x0Ei0R24qDbVtyy66',1,art + 'Music.png')
        addDir('שנות ה 80&90','PL3485902CC4FB6C67',1,art + 'Music.png')
        addDir('להיטי שנות ה 70','PLGBuKfnErZlAkaUUy57-mR97f8SBgMNHh',1,art + 'Music.png')
        addDir('להיטי שנות ה 60','PLuK6flVU_Aj5EJ9Pp-C9N7XA0YJr_GrJI',1,art + 'Music.png')
        addDir('להיטי שנות ה 50','PLuK6flVU_Aj45QZ_A5ld0-pP3CIkoNQDk',1,art + 'Music.png')
        addDir('להיטי קאנטרי','PL2BN1Zd8U_MsyMeK8r9Vdv1lnQGtoJaSa',1,art + 'Music.png')
		
def travel():
        addDir('ערוץ הטיולים - לטייל','PLeh1TPHGKHcC0frpxT30gpX32Mc1DMStx',1,art + 'travel.png')
        addDir('המדריך לתייר בגלקסיה','PLeh1TPHGKHcAriEIJEPLnZ7Qsm3Fh6ELx',1,art + 'travel.png')
        addDir('אוכל רחוב מסביב לעולם','PLnzhIyrsnB5bZ3Cl2t98Ir4L82QCdetNq',1,art + 'travel.png')
        addDir('סקי וסנובורד','PLFZHg-6S5_GcrVsP97cT7KoYQQD5vNEQr',1,art + 'travel.png')
        addDir('טיולי משפחות','PLFZHg-6S5_GfMOlbWErniSqxw9ygllSGL',1,art + 'News.png')
        addDir('עצות המומחים - כל מה שצריך לדעת על ציוד טיולים','PLFZHg-6S5_GcQdP7V_Q3-6HF9pTUWQ8I_',1,art + 'travel.png')
        addDir('סרטונים פופולריים – Travel Channel','PL_xzw4jKGLrlQKx7hvUF5B5FvVhzUtvw6',1,art + 'travel.png')
        addDir('אוכל ביזארי עם Andrew Zimmern','PL7Yaf7nQHP3CM6bLT6acdsOhQoKCmb75c',1,art + 'News.png')
        addDir('סרטונים פופולריים – Aerial America','PLnr8iIChmNnEy89DZIe6DKSeS4qKAe1hx',1,art + 'News.png')
        addDir('סרטונים פופולריים – Hotel Impossible','PLF_H8SZXratCdL4Mv3fHRVfnj2SYw3bxr',1,art + 'News.png')
		
def cooking():
        addDir(''+translate(70002)+'','PLnzhIyrsnB5YJYfCNr4B9ewwTMhzS8pn9',1,art + 'cooking.png')
        addDir(''+translate(70003)+'','PLnzhIyrsnB5ZjRuqUWplT_8GGcVS6lKFN',1,art + 'cooking.png')
        addDir(''+translate(70004)+'','PLnzhIyrsnB5ZNE1PhI4hWyyvE6gbieoFs',1,art + 'cooking.png')       
        addDir('סודות מתוקים עונה 1','ELAMi0KPlVcsg',1,art + 'cooking.png')
        addDir('סודות מתוקים עונה 3','ELmeqByVOghVE',1,art + 'cooking.png')
        addDir('שגב במטבח','CLWEuLXV2ejHk',1,art + 'cooking.png')         
        addDir('מיקי שמו','PLqQIVRFHrR1rsA0RqsAkzMxa2Xc4tcO25',1,art + 'cooking.png')
        addDir('בישולים','PLkSacTgmGKr6a6sPE1F7q3VF7T00lffQc',1,art + 'cooking.png')
        addDir('בישולים 2','PLdDyYBhRKiyG21-epuoI57b7zBfAyQcvI',1,art + 'cooking.png') 
        addDir('לאכול - יסודות הבישול - ויקטור גלוגר','PL8jMo70ebRM5dsJOjJXzGylZny1dnFPI7',1,art + 'cooking.png')         
        addDir('לאכול - חומרי גלם - אוראל קמחי','PL8jMo70ebRM778yBMGXg5Bb0wKm60wtb3',1,art + 'cooking.png')
        addDir('לאון אל דנטה','PL8jMo70ebRM7nnRez1MyfKBFLTj9jzl1V',1,art + 'cooking.png')
        addDir('במטבח עם אמא','PL8jMo70ebRM6gYuy9d7yoPLTGg1asK78w',1,art + 'cooking.png')
        addDir('מיקי שמו עושה בית ספר - עונה ראשונה','PL8jMo70ebRM7tvFCZsiXhakIsbDwHOe9c',1,art + 'cooking.png')         
        addDir('מועדון ארוחת הבוקר עם אביב משה','PL8jMo70ebRM6CAq8sKdjfI4_N3qUO5U1j',1,art + 'cooking.png')
        addDir('פשוט לאפות','PL8jMo70ebRM6aT0ZciSlv_YhP2Kjp1tuk',1,art + 'cooking.png')
        addDir('המטבחון של ירון','PL156601B302C8F462',1,art + 'cooking.png')
		
def liveshows():
        addDir('זמרים ישראליים','PLnzhIyrsnB5Ydr8diBFqJ368vCrqAlfbS',1,art + 'liveshows.png')
        addDir('להקות','PLnzhIyrsnB5ai_vMjsjdipIVDNOzf7qAA',1,art + 'liveshows.png')
        addDir('זמרים לועזית','PLnzhIyrsnB5ZPMlMCdRHmuOtbze7KnaSO',1,art + 'liveshows.png')
        addDir('מוזיקה אלקטרונית','PLnzhIyrsnB5Zf1NEU60_WpvDnjC3DJie2',1,art + 'liveshows.png')
        addDir('להקות רוק','PLnzhIyrsnB5YK-6PY7QT3_MEyRRmqoM7N',1,art + 'liveshows.png')
        addDir('פופ','PLnzhIyrsnB5YLbrr7a_74BPOdF72JXUVj',1,art + 'liveshows.png')
        addDir('קאנטרי','PLnzhIyrsnB5bt4BgqZt_p5qs3sewWKYMs',1,art + 'liveshows.png')
        addDir('סול','PLnzhIyrsnB5ZJnBhU7CzXeyxOUPTiZngx',1,art + 'liveshows.png')
        addDir('בלוז','PLnzhIyrsnB5ZKprmMzQPYkxX24l967jvx',1,art + 'liveshows.png')
        addDir('ראפ & היפ הופ','PLnzhIyrsnB5Zoqn0X5E3Brl_2PTvOcxBd',1,art + 'liveshows.png')
        addDir('גאז','PLnzhIyrsnB5Y2TRvmL4HIvqDg2EJO5PmU',1,art + 'liveshows.png')
		
def Sports():        
        addDir('כדורסל','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',32,art + 'Sports.png')	
        addDir('כדורגל','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',33,art + 'Sports.png')
        #addDir('טניס','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',32,art + 'Sports.png')	
        #addDir('אתלטיקה קלה','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',32,art + 'Sports.png')
        #addDir('כדורעף','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',32,art + 'Sports.png')	
        #addDir('כדוריד','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',32,art + 'Sports.png')
        #addDir('שחיה','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',32,art + 'Sports.png')
        #addDir('כושר ואירובי','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',32,art + 'Sports.png')
        #addDir('מרוצי מכוניות','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',32,art + 'Sports.png')
        #addDir('פיתוח גוף','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',32,art + 'Sports.png')
        #addDir('ספורט אתגרי','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',32,art + 'Sports.png')		
        #addDir('ספורט ימי','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',32,art + 'Sports.png')
        #addDir('סקי','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',32,art + 'Sports.png')		
        #addDir('פוקר','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',32,art + 'Sports.png')
        addDir('קרבות ufc','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',1,art + 'Sports.png')
        #addDir('קרבות MMA','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',1,art + 'Sports.png')
        #addDir('אגרוף','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',1,art + 'Sports.png')		
		
def basket():        
        addDir('NBA','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',31,art + 'Sports.png')	
        addDir('משחקים מלאים NCAA','PL6Bd4hQKgOo81RSUYKV9ko4KzNFPoKgVB',1,art + 'Sports.png')
        addDir('משחקי כדורסל מלאים ישראל','PLlvkid9n7uGRKawARkwySZp9zCALaMeJb',1,art + 'Sports.png')
        addDir('כדורסל מכבי תל אביב משחקים מלאים','PLCWRG1vLyuBKLfX_NspXzY8VcAOU6wJwR',1,art + 'Sports.png')
        addDir('כדורסל מכבי תל אביב משחקים מלאים','PLGU699iLiZVtqvNmge4rcS10ZBvsZ4CIU',1,art + 'Sports.png')
        addDir('כדורסל מכבי תל אביב רגעים גדולים 2014-2015','PLCWRG1vLyuBJBiOhIp7euSSJwYMbhqz1V',1,art + 'Sports.png')
        addDir('הפועל ירושלים משחקים מלאים','PLGU699iLiZVumCl6JWOlZM6-e8YrujVBy',1,art + 'Sports.png')
        addDir('סרטונים פופולריים – כדורסל','PLS3UB7jaIERxGmq_9fD24tSLwyuZd7vDm',1,art + 'Sports.png')

def soccer():        
        addDir('ליגת העל 2015/16 תקצירים','PLGU699iLiZVuPT08tKaihvzGHzi7TpKp4',1,art + 'Sports.png')	       	
        addDir('כדורגל ישראלי  תקצירים מורחבים','PLGU699iLiZVsKwGIk7wqlBaDDc_PueD3i',1,art + 'Sports.png')
        addDir('ליגת העל 2015/16  משחקים מלאים','PLGU699iLiZVuvOHl8tbClblRnO7gpRuYy',1,art + 'Sports.png')
        addDir('ליגת העל 2015-16 - משחקים מלאים ספורט 1','PLTu-AmawV8D0hGSk_MThaag1jJQ9853z3',1,art + 'Sports.png')
        addDir('גביע המדינה 2015-16 - משחקים מלאים ספורט 1','PLTu-AmawV8D1AFZcpPwWw6FbvFVAXTSLD',1,art + 'Sports.png')
        addDir('הישראליות באירופה  משחקים מלאים','PLGU699iLiZVtyufLTgFM06rTPORQqMasi',1,art + 'Sports.png')
        addDir('ספורט ONE מכבי חיפה','PLTu-AmawV8D2yNMxtKOmc1leheIrXgbfp',1,art + 'Sports.png')
        addDir('ספורט ONE מכבי תל אביב','PLTu-AmawV8D1I2RLIuqCgn4ivpV5wqPjO',1,art + 'Sports.png')
        addDir('ספורט ONE הפועל תל אביב','PLTu-AmawV8D0C5KPwVlurnJP4KkjIkgMo',1,art + 'Sports.png')
        addDir('ביתר ירושלים ספורט 1','PLTu-AmawV8D3b16u3378Sx6xOlGzc5ZDj',1,art + 'Sports.png')
        addDir('מכבי נתניה ספורט 1','PLTu-AmawV8D1mWDpHPOD8qts2GoSin1xU',1,art + 'Sports.png')
        addDir('מכבי פתח תקווה ספורט 1','PLTu-AmawV8D1usI_4UHXslajV6oBm3ibo',1,art + 'Sports.png')
		
def NBA():
        addDir('2015-16 Top 10s of the Week','PLlVlyGVtvuVkO2UhE8VWy0YRaBNXMXJ5P',1,art + 'Sports.png')
        addDir('2016 All-Star Top 10','PLnzhIyrsnB5ai_vMjsjdipIVDNOzf7qAA',1,art + 'Sports.png')
        addDir('Nba Hardwood Classic Games','PLgaLmcSQmPmypokd-3BPPJqtKjzgRdRZu',1,art + 'Sports.png')
        addDir('Inside the NBA Funniest Moments','PLFHl_hR47OGIqrn4A1tlQmteFKBKTskGx',1,art + 'Sports.png')
        addDir('סרטונים פופולריים – ליגת ה-NBA & הדיילי שואו','PLcU0PpBCNEcaXFJXvI6uKBZ_XqOWvTkvy',1,art + 'Sports.png')
        addDir('inside the nba - 2014-2015 NBA Season ','PL7XTBoSLULm0XE6K_PFqZtnZoU98JAoVe',1,art + 'Sports.png')
        addDir('inside the nba - 2015-2016 NBA Season','PL7XTBoSLULm16wQ6MiXEoRc9oGuj0geNZ',1,art + 'Sports.png')
        addDir('NBA full games','PLZyXUPrBBStUgi8dE4_zo_mNFaQ_JvbeL',1,art + 'Sports.png')
        addDir('NBA Greatest Games','PLMATWUx3t7L_pHQ56TR3wu_G0YzlQl7RP',1,art + 'Sports.png')
        addDir('סרטונים פופולריים – דראפט ה-NBA & 2016 NBA draft','PLVpg6d1IB7cyIGsARLbnMWXi-yhsBrpTm',1,art + 'Sports.png')
 
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param


params=get_params()
url=None
name=None
mode=None
iconimage=None
page = None
token = None

try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except:
	try: 
		mode=params["mode"]
	except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: token=urllib.unquote_plus(params["token"])
except: pass
try: page=int(params["page"])
except: page = 1

print ("Mode: "+str(mode))
print ("URL: "+str(url))
print ("Name: "+str(name))
print ("iconimage: "+str(iconimage))
print ("Page: "+str(page))
print ("Token: "+str(token))

		
def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def create_directory(dir_path, dir_name=None):
    if dir_name:
        dir_path = os.path.join(dir_path, dir_name)
    dir_path = dir_path.strip()
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
    return dir_path

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        return_youtubevideos(name,url,token,page)

elif mode==5: 
        play_youtube_video(url)

elif mode==6:
        mark_as_watched(url)

elif mode==7:
        removed_watched(url)

elif mode==8:
        add_to_bookmarks(url)

elif mode==9:
        remove_from_bookmarks(url)
		
elif mode==10:
        print ""+url
        lifestyle()
		
elif mode==11:
        print ""+url
        documentary()

elif mode==12:
        print ""+url
        kids()

elif mode==13:
        print ""+url
        Music()
        
elif mode==14:
        print ""+url
        travel()

elif mode==15:
        print ""+url
        Sports()

elif mode==16:
        print ""+url
        liveshows()

elif mode==17:
        print ""+url
        cooking()
			
elif mode==18:
        print ""+url
        junior()
		
elif mode==19:
        print ""+url
        nickjunior()

elif mode==20:
        print ""+url
        nicklodeon()

elif mode==21:
        print ""+url
        logy()

elif mode==22:
        print ""+url
        hop()

elif mode==23:
        print ""+url
        hopy()	

elif mode==24:
        print ""+url
        luly()

elif mode==25:
        print ""+url
        baby()

elif mode==26:
        print ""+url
        hot()

elif mode==27:
        print ""+url
        kidstv()

elif mode==28:
        print ""+url
        ch23()

elif mode==29:
        print ""+url
        zoom()		

elif mode==30:
        print ""+url
        dsjunior()

elif mode==31:
        print ""+url
        NBA()

elif mode==32:
        print ""+url
        basket()

elif mode==33:
        print ""+url
        soccer()		

xbmcplugin.endOfDirectory(int(sys.argv[1]))
