import xbmcaddon

MainBase = 'https://raw.githubusercontent.com/amshpitz/repository.lahav/master/LiveTV/HomeShow.txt'
addon = xbmcaddon.Addon('plugin.video.ShpitzShow')