import sys
import xbmc
import xbmcplugin
import icast
import config
import routing
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem, endOfDirectory


# Set type of plugin:
addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
# Create routing plugin:
plugin = routing.Plugin()


# Intro
@plugin.route('/')
def index():
    xbmc.executebuiltin('Notification(Kodcast,This addon is based on live data and hence may become slower depends on your network & hardware,5000)')

    # Get all channels:
    for channel in icast.get_channels():
        # channel's fanart path
        fanart = icast.get_channel_fanart(config.ADDON_ID, channel.id)
        li = ListItem(channel.name, '', 'DefaultFolder.png')
        li.setArt({'thumb': 'DefaultFolder.png', 'fanart': fanart})
        addDirectoryItem(plugin.handle, plugin.url_for(show_channel, channel.id), li, True)

    endOfDirectory(plugin.handle)


@plugin.route('/channel/<channel_id>')
def show_channel(channel_id):
    # channel's fanart path
    fanart = icast.get_channel_fanart(config.ADDON_ID, channel_id)
    # Get channel's podcasts:
    for link in icast.get_podcasts_pages('{0}/default.aspx?c={1}'.format(config.BASE_URL, str(channel_id))):
        for podcast in icast.get_podcasts('{0}/{1}'.format(config.BASE_URL, link)):
            li = ListItem(podcast.name, podcast.description, podcast.image)
            li.setArt({'thumb': podcast.image, 'fanart': fanart})
            addDirectoryItem(plugin.handle, plugin.url_for(show_podcast, channel_id, podcast.id), li, True)

    endOfDirectory(plugin.handle)


@plugin.route('/channel/<channel_id>/podcast/<podcast_id>')
def show_podcast(channel_id, podcast_id):
    # channel's fanart path
    fanart = icast.get_channel_fanart(config.ADDON_ID, channel_id)
    # Get podcast RSS:
    soup = icast.get_podcast(podcast_id)
    for item in soup.find_all('item'):
        li = ListItem(item.title.get_text(), item.description.get_text(), soup.rss.channel.image.url.get_text())
        li.setArt({'thumb': soup.rss.channel.image.url.get_text(), 'fanart': fanart})
        li.setInfo('music', {'Title': item.title.get_text(), 'Artist': 'Kodcast'})
        li.setProperty('mimetype', 'audio/mpeg')
        li.setProperty('IsPlayable', 'true')
        addDirectoryItem(plugin.handle, item.link.get_text(), li)

    endOfDirectory(plugin.handle)


if __name__ == '__main__':
    plugin.run()
