import re


class Channel:
    def __init__(self, name, url):
        self.id = re.search('&c=(\d+)$', url).group(1)
        self.name = name
        self.url = url
